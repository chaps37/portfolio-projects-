<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$file_path = "reviews.json";

// If the file does not exist, create an empty JSON file
if (!file_exists($file_path)) {
    file_put_contents($file_path, json_encode([]));
}

$reviews = json_decode(file_get_contents($file_path), true);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $input = json_decode(file_get_contents("php://input"), true);
    $reviews[] = $input;
    file_put_contents($file_path, json_encode($reviews, JSON_PRETTY_PRINT));
    echo json_encode(["message" => "Review saved"]);
    exit;
}

echo json_encode($reviews);
?>
