<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// Read JSON data from request
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data["totalPrice"])) {
    echo json_encode(["status" => "error", "message" => "Invalid payment data"]);
    exit;
}

// Simulate processing payment
$response = [
    "status" => "success",
    "message" => "Payment of $" . $data["totalPrice"] . " received."
];

echo json_encode($response);
?>
