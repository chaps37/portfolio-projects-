<?php
header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 1); // Enable debugging

$servername = "localhost";
$username = "root";
$password = "";
$database = "offbeat";

// Database connection
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Decode JSON data from frontend
$data = json_decode(file_get_contents("php://input"), true);

// Debugging: Log received data
file_put_contents("log.txt", print_r($data, true)); // Check log.txt for debugging

if (isset($data['storeCode']) && isset($data['totalPrice'])) {
    $storeCode = $data['storeCode'];
    $totalPrice = floatval($data['totalPrice']);

    //  Debugging: Log values before inserting
    error_log("Inserting: Store Code: $storeCode, Total: $totalPrice");

    // Remove Date_Issued from query (only insert Store_Code and Total_Price)
    $stmt = $conn->prepare("INSERT INTO shopping (Store_Code, Total_Price) VALUES (?, ?)");
    $stmt->bind_param("sd", $storeCode, $totalPrice);

    if ($stmt->execute()) {
        $receiptId = $conn->insert_id; // Get inserted Receipt_Id
        echo json_encode(["status" => "success", "receiptId" => $receiptId]);
    } else {
        echo json_encode(["status" => "error", "message" => "Database error: " . $stmt->error]);
    }

    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid data"]);
}

$conn->close();
?>
