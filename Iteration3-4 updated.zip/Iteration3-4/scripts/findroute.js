app.service("OnlineServiceApp", function() {
    var directionsService, directionsRenderer, map;

    this.initMap = function() {
        map = new google.maps.Map(document.getElementById("map"), {
            zoom: 5,
            center: { lat: 43.6532, lng: -79.3832 } // Center of Canada
        });

        directionsService = new google.maps.DirectionsService();
        directionsRenderer = new google.maps.DirectionsRenderer();
        directionsRenderer.setMap(map);
    };

    this.calculateRoute = function(warehouseLocation, customerAddress) {
        if (!customerAddress) {
            alert("Please enter a delivery address.");
            return;
        }

        var request = {
            origin: { lat: parseFloat(warehouseLocation[0]), lng: parseFloat(warehouseLocation[1]) },
            destination: customerAddress,
            travelMode: google.maps.TravelMode.DRIVING
        };

        directionsService.route(request, function(result, status) {
            if (status === "OK") {
                directionsRenderer.setDirections(result);
            } else {
                alert("Could not find a route. Please check the address.");
            }
        });
    };
});
