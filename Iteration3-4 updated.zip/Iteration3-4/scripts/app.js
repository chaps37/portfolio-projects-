



// Configure Routes
var app = angular.module("OnlineServiceApp", ["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "views/home.html",
            controller: "HomeController"
        })
        .when("/about", {
            templateUrl: "views/about.html",
            controller: "AboutController"
        })
        .when("/shopping", {
            templateUrl: "views/shopping.html",
            controller: "ShoppingController"
        })
        .when("/cart", {
            templateUrl: "views/cart.html",
            controller: "ShoppingController"
        })
        .when("/invoice", {
            templateUrl: "views/invoice.html",
            controller: "ShoppingController"
        })
        .when("/pay", {
            templateUrl: "views/pay.html",
            controller: "PaymentController"
        })
        .when("/delivery", {
            templateUrl: "views/delivery.html",
            controller: "DeliveryController"
        })
        .when("/reviews", {
            templateUrl: "views/review.html",
            controller: "ReviewController"
        })
        .when("/signup", {
            templateUrl: "views/signup.html",
            controller: "SignupController"
        })
        .when("/login", {
            templateUrl: "views/login.html",
            controller: "LoginController"
        })
        .otherwise({
            redirectTo: "/"
        });
});


app.controller("HomeController", function($scope, $location) {
    $scope.departments = [
        { name: "Furniture", image: "images/furniture.jpg", description: "Everything for the House", link: "#!/shopping" },
        { name: "Footwear", image: "images/nikeSB.jpg", description: "Men, Women, Kids", link: "#!/shopping" },
        { name: "Appliances", image: "images/electrics.jpg", description: "Everything for the House", link: "#!/shopping" },
        { name: "Kitchen", image: "images/kitchen.jpg", description: "Everything for the Kitchen", link: "#!/shopping" },
        { name: "Beauty", image: "images/beauty.jpg", description: "Skincare, Makeup", link: "#!/shopping" },
        { name: "Clothing", image: "images/cloths.jpg", description: "Men, Women, Kids", link: "#!/shopping" },
        { name: "Bags", image: "images/bags.jpg", description: "For her", link: "#!/shopping" }
    ];

    // Function to navigate to department
    $scope.goToDepartment = function(link) {
        $location.path(link.replace("#!", "")); 
    };
    
});

app.controller("ShoppingController", function($scope, $http) {
    // Define the product list
    $scope.products = [
        { id: 1, name: "Adi2000", price: 75, brand: "Adidas", image: "images/adi2000.jpg", discount: "30% off" },
        { id: 2, name: "Salomon XT-6", price: 160, brand: "Salomon", image: "images/salomon.jpg" },
        { id: 3, name: "Air Max Plus Drift", price: 240, brand: "Nike", image: "images/airMax.jpg" },
        { id: 4, name: "Gumball Gazelle", price: 160, brand: "Adidas", image: "images/gumball_gazelle.jpg", discount: "15% off" }
    ];
    
    // Initialize shopping cart from localStorage or as an empty array
    $scope.cart = JSON.parse(localStorage.getItem("cart")) || [];

    // Initialize discount-related variables
    $scope.discountCode = '';
    $scope.discountApplied = false;
    $scope.discountError = false;

    // Predefined valid discount code (10% off)
    const validDiscountCode = "DISCOUNT10";  // 10% discount

    // Function to apply the discount code
    $scope.applyDiscount = function() {
        if ($scope.discountCode === validDiscountCode) {
            $scope.discountApplied = true;
            $scope.discountError = false;
            // Apply 10% discount to each item in the cart
            $scope.cart.forEach(item => {
                item.discountedPrice = item.price * 0.9; // 10% off
            });
            localStorage.setItem("cart", JSON.stringify($scope.cart));
        } else {
            $scope.discountApplied = false;
            $scope.discountError = true;
        }
    };

    // Function to add products to the cart
    $scope.addToCart = function(product) {
        var existing = $scope.cart.find(item => item.id === product.id);
        if (existing) {
            existing.quantity += 1;
        } else {
            let newProduct = angular.copy(product);
            newProduct.quantity = 1;
            newProduct.discountedPrice = newProduct.price; // Initially no discount
            $scope.cart.push(newProduct);
        }
        
        localStorage.setItem("cart", JSON.stringify($scope.cart));
        $scope.$applyAsync(); // Ensure UI updates
    };

    // Function to remove items from the cart
    $scope.removeFromCart = function(index) {
        $scope.cart.splice(index, 1);
        localStorage.setItem("cart", JSON.stringify($scope.cart));
    };

    // Function to calculate the total price of the cart
    $scope.calculateTotal = function() {
        return $scope.cart.reduce((total, item) => {
            return total + (item.discountedPrice || item.price) * item.quantity;
        }, 0);
    };

    // Function to calculate invoice details
    $scope.calculateInvoice = function() {
        let subtotal = $scope.cart.reduce((total, item) => total + (item.discountedPrice || item.price) * item.quantity, 0);
        let discount = 0;
        if ($scope.discountApplied) {
            discount = subtotal * 0.1; // 10% discount
        }
        let hst = subtotal * 0.13; // Assuming 13% tax rate
        let delivery = subtotal > 300 ? 0 : 10; // Free delivery if order > $100
        let total = subtotal - discount + hst + delivery;

        return {
            subtotal: subtotal.toFixed(2),
            discount: discount.toFixed(2),
            hst: hst.toFixed(2),
            delivery: delivery.toFixed(2),
            total: total.toFixed(2)
        };
    };

    // Function to checkout and generate the invoice
    $scope.checkout = function() {
        localStorage.setItem("cart", JSON.stringify($scope.cart));
        window.location = "#!/invoice"; // Redirect to invoice page
    };

    // Function to proceed to payment
    $scope.proceedToPayment = function() {
        let invoice = $scope.calculateInvoice(); 
        localStorage.setItem("invoice", JSON.stringify(invoice)); // Store full invoice
        localStorage.setItem("totalPrice", invoice.total); // Store total separately
        window.location = "#!/pay"; // Redirect to payment page
    };

    // Function to handle drag event
    $scope.dragStart = function(event, product) {
        event.dataTransfer.setData("product", JSON.stringify(product));
    };

    // Function to handle drop event for adding products to the cart
    $scope.drop = function(event) {
        event.preventDefault();
        let productData = event.dataTransfer.getData("product");
        let product = JSON.parse(productData);

        // Check if item already exists in the cart
        let existingItem = $scope.cart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            product.quantity = 1;
            $scope.cart.push(product);
        }

        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify($scope.cart));

        // Update Angular scope
        $scope.$apply();
    };

    // Debugging
    console.log("ShoppingController initialized", $scope.cart);
});

    



app.controller("PaymentController", function ($scope, $http, $window) {
    $scope.payment = {
        method: "credit",
        cardNumber: "",
        expiryDate: "",
        cvv: "",
        giftCardCode: ""
    };

    // Restore cart from localStorage
    $scope.cart = JSON.parse(localStorage.getItem("cart")) || []; 

    // Update payment fields based on selected method
    $scope.updatePaymentFields = function () {
        // Reset fields when changing payment method
        $scope.payment.cardNumber = "";
        $scope.payment.expiryDate = "";
        $scope.payment.cvv = "";
        $scope.payment.giftCardCode = "";
    };

    // Process payment and handle cart reset
    $scope.processPayment = function () {
        alert("Payment Successful!");

        // Prepare receipt data
        let receiptData = {
            storeCode: "STORE123",  // Replace with actual store logic if necessary
            totalPrice: parseFloat(localStorage.getItem("totalPrice")) || 0
        };

        // Send receipt data to the backend
        $http.post("classes/shopping.php", receiptData)
            .then(function (response) {
                if (response.data.status === "success") {
                    alert("Receipt Generated: ID " + response.data.receiptId);

                    // Clear cart and related data
                    $scope.cart = [];
                    localStorage.setItem("cart", JSON.stringify($scope.cart));

                    // Reset other localStorage items related to the cart
                    localStorage.setItem("favoriteTables", JSON.stringify([]));
                    localStorage.setItem("invoice", JSON.stringify({
                        subtotal: "0.00",
                        discount: "0.00",
                        hst: "0.00",
                        delivery: "0.00",
                        total: "0.00"
                    }));
                    localStorage.setItem("totalPrice", "0.00");

                    // Optionally remove discount code
                    localStorage.removeItem("discountCode");

                } else {
                    console.error("Error:", response.data.message);
                }
            })
            .catch(function (error) {
                console.error("Error saving receipt:", error);
            });
    };

    // Navigate to the home page
    $scope.goHome = function() {
        $window.location.href = '/'; // Or specify the exact path like '/home' or '/index.html'
    };
});




app.controller("ReviewController", function($scope, $http) {
    $scope.review = { rating: 5, text: "" };
    $scope.reviews = [];

    $scope.submitReview = function() {
        let newReview = { rating: $scope.review.rating, text: $scope.review.text };

        // Save to database (Assuming a PHP backend)
        $http.post("classes/review.php", newReview)
            .then(response => {
                console.log("Review saved:", response.data);
                $scope.reviews.push(newReview);
                $scope.review.text = ""; // Reset form
            })
            .catch(error => console.error("Error saving review:", error));
    };

    // Fetch existing reviews
    $scope.loadReviews = function() {
        $http.get("classes/review.php")
            .then(response => $scope.reviews = response.data)
            .catch(error => console.error("Error loading reviews:", error));
    };

    $scope.loadReviews();
});

app.controller("DeliveryController", function($scope, $http, $window) {
    // Form data
    $scope.delivery = {
        warehouse: "40.7128,-74.0060", // Default to New York Warehouse
        customerAddress: "",
        deliveryDate: ""
    };

    // Google Maps initialization
    function initMap() {
        // Set initial map position to New York
        var map = new google.maps.Map(document.getElementById("map"), {
            zoom: 10,
            center: {lat: 40.7128, lng: -74.0060}
        });

        $scope.calculateRoute(map); // Call to calculate route after map load
    }

    // Route calculation
    $scope.calculateRoute = function(map) {
        var directionsService = new google.maps.DirectionsService();
        var directionsRenderer = new google.maps.DirectionsRenderer();

        directionsRenderer.setMap(map);

        // Parse the selected warehouse's coordinates
        var warehouseCoords = $scope.delivery.warehouse.split(",");
        var warehouseLatLng = new google.maps.LatLng(parseFloat(warehouseCoords[0]), parseFloat(warehouseCoords[1]));

        // Customer's address
        var customerAddress = $scope.delivery.customerAddress;

        if (!customerAddress) {
            alert("Please enter a customer address.");
            return;
        }

        // Request directions from warehouse to customer address
        var request = {
            origin: warehouseLatLng,
            destination: customerAddress,
            travelMode: google.maps.TravelMode.DRIVING
        };

        directionsService.route(request, function(result, status) {
            if (status == google.maps.DirectionsStatus.OK) {
                directionsRenderer.setDirections(result);
            } else {
                alert("Could not find a route. Please try again.");
            }
        });
    };

    // Initialize Google Maps when the page loads
    google.maps.event.addDomListener(window, "load", initMap);

    // Go back button logic
    $scope.goBack = function() {
        $window.location.href = 'shopping.html';
    };
});














    

// Add other controllers as needed
