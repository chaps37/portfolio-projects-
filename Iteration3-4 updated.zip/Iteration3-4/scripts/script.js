document.addEventListener("DOMContentLoaded", () => {
    const productContainers = [...document.querySelectorAll('.product-container')];
    const departmentContainers = [...document.querySelectorAll('.department-container')];
    const nxtBtn = [...document.querySelectorAll('.nxt-btn')];
    const preBtn = [...document.querySelectorAll('.pre-btn')];

    productContainers.forEach((item, i) => {
        let containerDimensions = item.getBoundingClientRect();
        let containerWidth = containerDimensions.width;

        if (nxtBtn[i]) {
            nxtBtn[i].addEventListener('click', () => {
                item.scrollLeft += containerWidth;
            });
        }

        if (preBtn[i]) {
            preBtn[i].addEventListener('click', () => {
                item.scrollLeft -= containerWidth;
            });
        }
    });

    departmentContainers.forEach((item, i) => {
        let containerDimensions = item.getBoundingClientRect();
        let containerWidth = containerDimensions.width;

        if (nxtBtn[i]) {
            nxtBtn[i].addEventListener('click', () => {
                item.scrollLeft += containerWidth;
            });
        }

        if (preBtn[i]) {
            preBtn[i].addEventListener('click', () => {
                item.scrollLeft -= containerWidth;
            });
        }
    });
});


