// Allow the drop action
function allowDrop(ev) {
    ev.preventDefault();
}

// Start dragging
function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

// Handle the drop event
function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    var item = document.getElementById(data);

    // Retrieve product details
    var name = item.getAttribute("data-name");
    var prodId = item.getAttribute("data-id");
    var price = parseFloat(item.getAttribute("data-price"));
    var madeIn = item.getAttribute("data-madeIn");
    var department = item.getAttribute("data-department")
    var productImage = item.querySelector("img"); // Find product image

    if (productImage) {
        // ✅ Update UI (Only Add Image)
        addItemToCartUI(name,prodId,madeIn,price,department, productImage.src);

        // ✅ Store in localStorage
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        let existingItem = cart.find(product => product.name === name);
        if (existingItem) {
            existingItem.quantity += 1; // Increase quantity
        } else {
            cart.push({ name, prodId, madeIn, price, department, image: productImage.src, quantity: 1 });
        }
        localStorage.setItem("cart", JSON.stringify(cart));

        // ✅ Update total price
        updateTotal(price);

        toggleEmptyCartMessage();
    }
}

// Function to toggle the empty cart message
function toggleEmptyCartMessage() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let emptyCartMessage = document.getElementById("empty-cart-message");
    
    if (cart.length === 0) {
        emptyCartMessage.style.display = "block";
    } else {
        emptyCartMessage.style.display = "none";
    }
    }







// Function to update the UI (Only Images in Cart)
function addItemToCartUI(name, prodId,  price, madeIn, department, imageSrc) {
    var cartContainer = document.getElementById("cart");
    var existingItem = document.querySelector(`.cart-item[data-name="${name}"]`);

    if (existingItem) {
        // If the item is already in the cart, update the quantity
        var quantitySpan = existingItem.querySelector(".quantity");
        quantitySpan.innerText = parseInt(quantitySpan.innerText) + 1;
    } else {
        // Create a new cart item div
        var cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");
        cartItem.setAttribute("data-name", name);
        cartItem.setAttribute("data-id", prodId);
        cartItem.setAttribute("data-madeIn", madeIn);
        cartItem.setAttribute("data-department", department);
        cartItem.setAttribute("data-price", price);

        // Clone and resize image
        var imgElement = document.createElement("img");
        imgElement.src = imageSrc;
        imgElement.style.width = "100%";   // Let the image be responsive
        imgElement.style.height = "auto";  // Maintain aspect ratio // Optional: Set the height
        imgElement.style.margin = "2px";  // Add spacing

        // Display image and quantity only
        var quantitySpan = document.createElement("span");
        quantitySpan.classList.add("quantity");
        quantitySpan.innerText = "1"; // Start with quantity 1

        // Attach click event to remove item
        cartItem.onclick = function () {
            removeFromCart(cartItem, name, price);
        };

        // Append image and quantity span
        cartItem.appendChild(imgElement);
        cartItem.appendChild(quantitySpan);
        cartContainer.appendChild(cartItem);
    }
}

// ✅ Restore cart on page load (Only Images)
document.addEventListener("DOMContentLoaded", function () {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let total = localStorage.getItem("totalPrice");

    // Initialize total to 0 if no total is stored
    if (total === null || isNaN(parseFloat(total))) {
        total = 0.00;
    } else {
        total = parseFloat(total);
    }

    // Set the initial total amount
    document.getElementById("total").innerText = "Total: $" + total.toFixed(2);

    // Add items back to the cart UI
    cart.forEach(item => {
        for (let i = 0; i < item.quantity; i++) {
            addItemToCartUI(item.name, item.prodId, item.madeIn, item.price, item.department, item.image);
        }
    });
});

// Function to update total price
function updateTotal(amount) {
    var totalElement = document.getElementById("total");
    var totalText = totalElement.innerText.replace("Total: $", "").trim();
    var total = isNaN(parseFloat(totalText)) ? 0 : parseFloat(totalText);

    // Update the total
    total += amount;

    // Prevent total from going negative
    if (total < 0) {
        total = 0;
    }

    totalElement.innerText = "Total: $" + total.toFixed(2);

    // Save the total price in localStorage
    localStorage.setItem("totalPrice", total.toFixed(2));
}

// Remove item from cart and update total
function removeFromCart(cartItem, itemName, price) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    // Find the item in cart and reduce its quantity or remove it
    let updatedCart = cart.map(item => {
        if (item.name === itemName) {
            if (item.quantity > 1) {
                item.quantity -= 1; // Reduce quantity
                return item;
            } else {
                return null; // Mark for removal
            }
        }
        return item;
    }).filter(Boolean); // Remove null values (items with 0 quantity)

    // Save updated cart to localStorage
    localStorage.setItem("cart", JSON.stringify(updatedCart));

    // Update UI
    var quantitySpan = cartItem.querySelector(".quantity");
    var currentQuantity = parseInt(quantitySpan.innerText);
    
    if (currentQuantity > 1) {
        quantitySpan.innerText = currentQuantity - 1;
    } else {
        cartItem.remove(); // Remove from UI if last one
    }

    // Update total price
    updateTotal(-price);
}
