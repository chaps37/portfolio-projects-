console.log("JavaScript file is loaded");

const form = document.getElementById('form')
const firstname_input = document.getElementById('firstname-input')
const email_input = document.getElementById('email-input')
const password_input = document.getElementById('password-input')
const repeat_password_input = document.getElementById('repeat-password-input')
const error_message = document.getElementById('error-message')


// Check if elements are found
console.log("Form element:", form);
console.log("First name input:", firstname_input);
console.log("Email input:", email_input);
console.log("Password input:", password_input);
console.log("Repeat password input:", repeat_password_input);
console.log("Error message element:", error_message);



form.addEventListener('submit', (e) => {
    //e.preventDefault();  Prevent default form submission

    let errors = getSignUpErrors(firstname_input.value, email_input.value, password_input.value, repeat_password_input.value);

    if (errors.length > 0) {
        error_message.innerText = errors.join(". ");
        error_message.style.color = 'red';
    } else {
        // Send form data to PHP
        const formData = new FormData(form);
        
        fetch('signup.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            console.log(data);
            error_message.innerText = data; // Show server response
            error_message.style.color = 'green';
        })
        .catch(error => console.error('Error:', error));
    }
});

function getSignUpErrors(firstname,email,password,repeatPassword){
    let errors = []

    if(firstname === '' || firstname == null){
        errors.push('Firstname is required')
        firstname_input.parentElement.classList.add('incorrect')
    }
    if(email === '' || email == null){
        errors.push('Email is required')
        email_input.parentElement.classList.add('incorrect')
    }
    if(password === '' || password == null){
        errors.push('Password is required')
        password_input.parentElement.classList.add('incorrect')
    }
    if(password.length < 8){
        errors.push('Password muist have at least 8 characters')
        password_input.parentElement.classList.add('incorrect')
    }
    
    if (repeatPassword !== password) {
        errors.push('Passwords do not match')
        repeat_password_input.parentElement.classList.add('incorrect')
        repeat_password_input.parentElement.classList.add('incorrect')
    }

    return errors;
}

function getLoginFormErrors(email,password){
    return errors
}
 const allInputs = [firstname_input,email_input, password_input, repeat_password_input].filter(input => input != null)

allInputs.forEach(input => {
    input.addEventListener('input', () => {
        if(input.parentElement.classList.contains('incorrect')){
            input.parentElement.classList.remove('incorrect')
            error_message.innerText = ''
        }

    })
})